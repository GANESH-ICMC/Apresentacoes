#include <stdio.h>

void cpy(char *src, char* dest){
	int i;
	for(i=0;src[i];i++)
		dest[i] = src[i];
}

int main(int argc, char **argv){
	char s[20];
	cpy(argv[1],s);
	return 0;
}
