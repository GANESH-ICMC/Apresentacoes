int main(){
	int a,b,c;
	a = 5;
	b = 2;
	c = a + b;
	return 0;
}
