#!/bin/bash

# Desvios condicionais
read -p "Digite sua senha: " -s s1
echo
read -p "Confirme sua senha: " -s s2
echo 

# Declaração enxuta de if, os espaços importam.
# Para utilizar aspas dentro de aspas coloque uma barra.
if [ $s1 = $s2 ]; then
	echo -e "As senhas conferem.\n\"$s1\" == \"$s2\""
else
	echo -e "Senha incorreta.\n\"$s1\" != \"$s2\""
fi

echo "Bem-Vindo ao elevador do CISC"

read -p "Digite o número do andar (1-3): " a1

# Comparação de Strings
# A flag -z verifica se a variável está vazia.
if [ -z $a1 ]; the
n	echo "Variável vazia."
elif [ $a1 = 1 ]; then
	echo "Primeiro andar."
elif [ $a1 = 2 ]; then
	echo "Segundo andar."
elif [ $a1 = 3 ]; then
	echo "Terceiro andar."
else
	echo "Andar inexistente!"
fi

# Verifica se um arquivo existe, se não existir o cria e o exclui.
if [ -e "$arquivo" ]; then
	echo `cat arquivo`
else
	echo "Arquivo não existe, criando arquivo..."	
	echo `echo "Arquivo criado." > arquivo`
	echo `ls -l arquivo`
	echo `cat arquivo`
	echo `rm arquivo`
	echo "Arquivo excluído..."
fi