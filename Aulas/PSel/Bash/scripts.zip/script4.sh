#!/bin/bash

# Funções

funcaoAleatorio() {
	echo "Função."
}

# OU

function funcao() {
	echo "Método arcaico."
}

funcaoAleatorio
funcao

funcaoComArgumento() {
	echo "Imprimindo todos os argumentos $@"
	echo "Imprimindo o primeiro argumento $1"
	echo "Imprimindo o segundo argumento $2"
}

#./script4.sh olá josué
funcaoComArgumento $1 $2