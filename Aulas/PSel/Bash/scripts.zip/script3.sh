#!/bin/bash

# Estrutura de repetição

# For
for ((i=0; i <= 5; i++))
do
    echo $i
done

# Declaração alternativa
for j in {5..10}
do
	echo $j
done

# Loop em elementos
for animal in "Leão" "Tigre" "Elefante"
do
	echo "$animal"
done

# While
# Para comparar números é necessário utilizar flags
# A flag -lt significa less than (estritamente menor que)
i=90
while [ "$i" -lt 100 ]
do
	echo -e "$i "	
	let "i = (i + 1)"
done

# Percorrendo pastas
# \t é um Tab
for arquivo in `ls`
do
	echo -e "\t $arquivo"	
done

# Declaração de vetor
# Precisa colocar entre chaves
vector=("Banana" "Maça" "Canela" "Banana_Frita")
for ((i=0; i <= 1; i++))
do
	echo ${vector[$i]}
done

# Printando tudo do vetor
echo ${vector[*]}