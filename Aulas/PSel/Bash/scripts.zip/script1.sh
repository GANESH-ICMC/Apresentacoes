#!/bin/bash

# Imprime na tela.
echo "Hello World!"

# A flag -e permite a utilização de '\n'.
echo -e "Hello\nWorld!"

# Não pode haver espaço entre o conteúdo e o =.
var0='xyz'

# Imprime o valor de uma variável.
echo "Imprimindo variável = $var0"

# Com aspas duplas considera o conteúdo da variável, com aspas simples considera como se fosse uma única string.
echo 'Imprimindo variável = $var0'

# Substituindo o conteúdo da variável.
echo ${var0/x/z}

# Substring de uma variável
Length=2
echo ${var0:0:Length}

# Declarando uma varíavel com um comando.
var1=`pwd`

# Comando pwd.
echo "Comando pwd: $var1"

# Combo de comandos
echo "Há $(ls | wc -l) arquivos aqui."

# Combo de comando sendo guardado em variável.
var2=`echo {1..10}`
echo $var2

# Lendo entrada do teclado
# Sugestão de inserção: Testando 123 456 789
# Separa por espaço e coloca em cada variável,
# Caso haja mais palavras do que variáveis,
# O restante é colocado na última variável.
read arg1 arg2 arg3

# Conferindo a leitura.
echo -e "$arg1\n$arg2\n$arg3"

# A flag -p permite a utilização de msg.
read -p "Mensagem de instrução: " arg4
echo $arg4

# A flag -n limita o número de caracteres.
read -p "Limitando o número de caracteres em 5: " -n 5 arg5
echo #Pulo de linha

# A flag -t limita o tempo para inserção.
read -p "Insira um comando rápido: " -t 0.1 arg6
echo "Demorou..."

# A flag -s esconde os caracteres.
read -p "Digite a sua senha: " -s arg7
echo $arg7

# O let pode ser usado para realizar operações matemáticas
# Porém as variáveis são consideradas como inteiro
let "a = 10"
let "b = 2"
let "c = a**b"
echo -e "a = 10\nb = 2\b\nc = a^b\n$c"

# Variáveis permantens para serem usadas em outros programas
echo `env` # Exibe todas as variáveis de ambiente