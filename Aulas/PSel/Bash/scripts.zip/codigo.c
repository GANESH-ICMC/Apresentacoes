#include <stdio.h>

int main() {
	system("ls -a");
	return 0;
}